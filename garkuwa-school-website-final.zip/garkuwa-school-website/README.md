# GARKUWA COMMUNITY YANDAKI Website

This is a complete website for GARKUWA COMMUNITY YANDAKI school, designed to replicate the functionality and design of the original Damale Schools website, with requested modifications.

## Features

- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Modern Layout**: Clean, professional design with smooth animations
- **Image Carousel**: Dynamic image carousel in the hero section
- **Navigation Menu**: Easy-to-use navigation with smooth scrolling, including Primary and Secondary sections
- **Latest News**: Dynamic news section for school updates
- **Noticeboard**: Section for important announcements
- **Entrepreneur Clubs**: Showcase of school programs including Programming, Tailoring, and Sack Farming
- **Primary Section**: Dedicated section for primary school information
- **Secondary Section**: Dedicated section for secondary school information
- **Contact Form**: Functional contact form that sends emails to mtechsolutions.ict@gmail.com
- **Mobile Menu**: Hamburger menu for mobile devices

## Removed Features

- Student Login
- Staff Login
- E-commerce (Store/Cart functionality)
- Apply Now Interface

## Files Structure

```
garkuwa-school-website/
├── index.html          # Main HTML file
├── styles.css          # CSS styling
├── script.js           # JavaScript functionality
├── images/             # Image assets folder
│   ├── FpaxIcQRfrth.jpg    # Graduation ceremony image
│   ├── fl3cudRXW6M3.jpg    # Programming class image
│   ├── cG5KIGVG0WMy.jpg    # Tailoring class image
│   ├── 3af5KrGZ1w0N.jpg    # Agriculture/farming image
│   ├── L0sZuTcot5Ej.jpg    # Happy Graduates image
│   ├── 22CwQSms6DpB.jpg    # Group of Graduates image
│   ├── U9yajxDyfUA7.jpg    # Primary School Students image
│   └── ... (other images)
└── README.md           # This file
```

## How to Use

1. **Local Testing**: Open `index.html` in any modern web browser
2. **Web Hosting**: Upload all files to your web hosting service
3. **Domain Setup**: Point your domain to the hosting directory

## Customization

### Changing Content
- Edit `index.html` to modify text content
- Update contact email in both HTML form and JavaScript validation
- Add/remove navigation items in the header section

### Styling Changes
- Modify `styles.css` to change colors, fonts, and layout
- The main color scheme uses maroon (#8B0000) as the primary color
- Responsive breakpoints are set for mobile devices (768px and below)

### Adding Functionality
- Edit `script.js` to add new interactive features
- Form validation is included for the contact form
- The image carousel is implemented with auto-slide and navigation controls

## Contact Information

- **School Name**: GARKUWA COMMUNITY YANDAKI
- **Email**: mtechsolutions.ict@gmail.com
- **Tagline**: "..to be the best"

## Technical Details

- **HTML5**: Semantic markup with accessibility features
- **CSS3**: Modern styling with flexbox and grid layouts
- **JavaScript**: Vanilla JS for interactivity and animations
- **Font Awesome**: Icons for social media and UI elements
- **Responsive**: Mobile-first design approach

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers (iOS Safari, Chrome Mobile)

## Deployment Options

1. **Static Hosting**: GitHub Pages, Netlify, Vercel
2. **Traditional Hosting**: cPanel, shared hosting services
3. **Cloud Hosting**: AWS S3, Google Cloud Storage

The website is ready for immediate deployment and use!

